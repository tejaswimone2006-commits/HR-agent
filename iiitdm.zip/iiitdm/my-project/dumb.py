import json
from datetime import datetime


# ==============================
# MOCK AI SERVICE
# ==============================

def analyze_resume(resume_text, job_skills):
    score = 0
    matched = []

    for skill in job_skills:
        if skill.lower() in resume_text.lower():
            matched.append(skill)
            score += 25

    return {
        "score": min(score, 100),
        "matched_skills": matched,
        "summary": f"Candidate matches {len(matched)} required skills."
    }


# ==============================
# HR AUTOMATION AGENT
# ==============================

class HRAgent:

    def __init__(self):
        self.logs = []

    def process_candidate(self, candidate, job_description):
        ai_result = analyze_resume(
            candidate["resume"],
            job_description["skills"]
        )

        decision = {
            "candidate_id": candidate["id"],
            "score": ai_result["score"],
            "matched_skills": ai_result["matched_skills"],
            "summary": ai_result["summary"],
            "status": "Selected" if ai_result["score"] >= 60 else "Rejected",
            "timestamp": str(datetime.now())
        }

        self.logs.append(decision)
        return decision

    def export_results(self):
        return json.dumps(self.logs, indent=4)


# ==============================
# MAIN EXECUTION
# ==============================

if __name__ == "__main__":

    # Sample Data
    candidate = {
        "id": 101,
        "resume": "Experienced in Python, Machine Learning and SQL."
    }

    job_description = {
        "skills": ["Python", "Machine Learning", "Django"]
    }

    agent = HRAgent()

    result = agent.process_candidate(candidate, job_description)

    print(result)


    print(agent.export_results())