import os
from dotenv import load_dotenv
from google import genai

load_dotenv()

api_key = os.getenv("GOOGLE_API_KEY")

print("Key Loaded:", api_key is not None)

client = genai.Client(api_key=api_key)

response = client.models.generate_content(
    model="gemini-1.5-flash",
    contents="Explain what an HR automation agent does."
)

print("\nGemini Response:\n")
print(response.text)