# interview/question_generator.py

from datetime import datetime


class InterviewQuestionGenerator:

    TECH_QUESTION_BANK = {
        "python": [
            "Explain Python decorators and their use cases.",
            "What is the difference between deep copy and shallow copy?",
            "Explain GIL in Python."
        ],
        "ml": [
            "Explain bias-variance tradeoff.",
            "What is overfitting and how do you prevent it?",
            "Explain cross-validation."
        ],
        "sql": [
            "What is indexing and how does it improve performance?",
            "Explain normalization.",
            "Write a query to find second highest salary."
        ],
        "java": [
            "Explain JVM architecture.",
            "What is the difference between HashMap and ConcurrentHashMap?"
        ],
        "rest": [
            "What are REST principles?",
            "Explain idempotent HTTP methods."
        ]
    }

    BEHAVIORAL_QUESTIONS = [
        "Describe a challenging technical problem you solved.",
        "How do you handle tight deadlines?",
        "Describe a time you disagreed with a team member.",
        "How do you prioritize tasks in a project?"
    ]

    def generate(self, candidate_id, skills, jd_text):
        technical_questions = []

        # Generate skill-based technical questions
        for skill in skills:
            if skill in self.TECH_QUESTION_BANK:
                technical_questions.extend(
                    self.TECH_QUESTION_BANK[skill][:2]
                )

        # If no direct match → fallback generic question
        if not technical_questions:
            technical_questions.append(
                "Explain your core technical expertise in detail."
            )

        difficulty = self._assess_difficulty(skills)

        return {
            "candidate_id": candidate_id,
            "generated_at": datetime.utcnow().isoformat() + "Z",
            "difficulty_level": difficulty,
            "technical": technical_questions,
            "behavioral": self.BEHAVIORAL_QUESTIONS[:3]
        }

    def _assess_difficulty(self, skills):
        if len(skills) >= 5:
            return "hard"
        elif len(skills) >= 3:
            return "medium"
        else:
            return "easy"