import imaplib
import email
import os
from dotenv import load_dotenv

load_dotenv()

EMAIL_USER = os.getenv("EMAIL_USER")
EMAIL_PASS = os.getenv("EMAIL_PASS")

DOWNLOAD_FOLDER = "email_downloads"


def fetch_resumes():
    print("Connecting to Gmail...")

    mail = imaplib.IMAP4_SSL("imap.gmail.com")
    mail.login(EMAIL_USER, EMAIL_PASS)

    print("Login successful!")

    mail.select("inbox")

    status, messages = mail.search(None, '(UNSEEN)')
    email_ids = messages[0].split()

    print("Unread email IDs:", email_ids)

    os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

    downloaded_files = []

    for e_id in email_ids:
        status, msg_data = mail.fetch(e_id, "(RFC822)")
        raw_email = msg_data[0][1]
        msg = email.message_from_bytes(raw_email)

        print("Processing email:", msg["Subject"])

        for part in msg.walk():
            if part.get_content_disposition() == "attachment":
                filename = part.get_filename()

                if filename and filename.lower().endswith((".pdf", ".docx")):
                    filepath = os.path.join(DOWNLOAD_FOLDER, filename)

                    with open(filepath, "wb") as f:
                        f.write(part.get_payload(decode=True))

                    print("Downloaded:", filepath)
                    downloaded_files.append(filepath)

    mail.logout()
    print("Finished checking emails.")

    return downloaded_files