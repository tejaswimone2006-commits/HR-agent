from datetime import datetime
import uuid


class PipelineStateManager:
    VALID_TRANSITIONS = {
        "applied": ["shortlisted", "rejected"],
        "shortlisted": ["interviewed", "rejected"],
        "interviewed": ["offered", "rejected"],
        "offered": ["hired", "rejected"],
        "hired": [],
        "rejected": []
    }

    TERMINAL_STATES = {"rejected", "hired"}

    def __init__(self):
        self.candidate_states = {}  # candidate_id -> current_state
        self.history_log = []  # audit trail

    def initialize_candidate(self, candidate_id):
        if candidate_id not in self.candidate_states:
            self.candidate_states[candidate_id] = "applied"
            self._log_transition(candidate_id, None, "applied", valid=True)

    def transition(self, candidate_id, new_state):
        if candidate_id not in self.candidate_states:
            raise ValueError("Candidate not initialized.")

        current_state = self.candidate_states[candidate_id]

        # Prevent transitions from terminal state
        if current_state in self.TERMINAL_STATES:
            self._log_transition(candidate_id, current_state, new_state, valid=False)
            return False, "Cannot transition from terminal state."

        # Check valid transitions
        if new_state in self.VALID_TRANSITIONS[current_state]:
            self.candidate_states[candidate_id] = new_state
            self._log_transition(candidate_id, current_state, new_state, valid=True)
            return True, "Transition successful."

        else:
            self._log_transition(candidate_id, current_state, new_state, valid=False)
            return False, "Invalid state transition."

    def _log_transition(self, candidate_id, from_state, to_state, valid):
        log_entry = {
            "log_id": str(uuid.uuid4()),
            "candidate_id": candidate_id,
            "from_state": from_state,
            "to_state": to_state,
            "timestamp": datetime.utcnow().isoformat(),
            "valid": valid
        }
        self.history_log.append(log_entry)

    def get_candidate_state(self, candidate_id):
        return self.candidate_states.get(candidate_id, None)

    def export_history(self):
        return self.history_log