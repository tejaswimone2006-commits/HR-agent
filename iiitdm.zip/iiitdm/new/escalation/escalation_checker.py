class EscalationEngine:

    CONFIDENCE_THRESHOLD = 0.6

    def check_leave_case(self, leave_decision):
        """
        Escalate if:
        - Missing evidence
        - Ambiguous rejection
        - Unknown error
        """

        if "policy_evidence" not in leave_decision:
            return self._escalate("Missing policy evidence.")

        if leave_decision["decision"] == "rejected":
            reason = leave_decision["policy_evidence"][0]

            if "Invalid" in reason:
                return self._escalate("Invalid input detected.")

            if "limit exceeded" in reason:
                return self._escalate("High-impact team leave conflict.")

        return {"escalate": False, "reason": "Decision deterministic and safe."}

    def check_pipeline_case(self, transition_result):
        """
        Escalate if repeated invalid transitions detected.
        """

        success, message = transition_result

        if not success:
            if "terminal state" in message:
                return self._escalate("Attempt to override terminal state.")
            if "Invalid state transition" in message:
                return self._escalate("Illegal pipeline state change attempt.")

        return {"escalate": False, "reason": "Pipeline state valid."}

    def check_scheduling_case(self, scheduling_result):
        """
        Escalate if no slot available or abnormal pattern.
        """

        success, result = scheduling_result

        if not success:
            return self._escalate("No valid interview slot found.")

        return {"escalate": False, "reason": "Scheduling successful."}

    def _escalate(self, reason):
        return {
            "escalate": True,
            "reason": reason
        }