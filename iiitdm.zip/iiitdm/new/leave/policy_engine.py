# leave/policy_engine.py

from datetime import datetime


class LeavePolicyEngine:

    ROLE_ELIGIBILITY = {
        "intern": ["casual"],
        "employee": ["casual", "sick", "earned"],
        "manager": ["casual", "sick", "earned", "special"]
    }

    MAX_TEAM_OVERLAP = 2  # max allowed employees on leave same day

    def __init__(self, leave_balances, existing_leaves):
        """
        leave_balances: dict
            {
                "E1": {"casual": 5, "sick": 3, "earned": 10}
            }

        existing_leaves: list
            [
                {"employee_id": "E2", "start": "2026-03-01", "end": "2026-03-03"}
            ]
        """
        self.leave_balances = leave_balances
        self.existing_leaves = existing_leaves

    def evaluate_request(self, employee_id, role, leave_type, start_date, end_date):

        decision_evidence = []

        # Convert to datetime
        start = datetime.fromisoformat(start_date)
        end = datetime.fromisoformat(end_date)

        if start > end:
            return self._reject("Invalid date range.")

        #  Role Eligibility Check
        if leave_type not in self.ROLE_ELIGIBILITY.get(role, []):
            return self._reject("Leave type not allowed for role.")

        decision_evidence.append("Role eligibility verified.")

        #  Balance Check
        days_requested = (end - start).days + 1
        available_balance = self.leave_balances.get(employee_id, {}).get(leave_type, 0)

        if available_balance < days_requested:
            return self._reject("Insufficient leave balance.")

        decision_evidence.append("Sufficient leave balance.")

        # Team Overlap Check
        overlap_count = 0

        for leave in self.existing_leaves:
            existing_start = datetime.fromisoformat(leave["start"])
            existing_end = datetime.fromisoformat(leave["end"])

            if start <= existing_end and end >= existing_start:
                overlap_count += 1

        if overlap_count >= self.MAX_TEAM_OVERLAP:
            return self._reject("Team overlap limit exceeded.")

        decision_evidence.append("No team conflict detected.")

        # If all checks pass → approve
        self.leave_balances[employee_id][leave_type] -= days_requested

        return {
            "employee_id": employee_id,
            "decision": "approved",
            "leave_type": leave_type,
            "days": days_requested,
            "policy_evidence": decision_evidence
        }

    def _reject(self, reason):
        return {
            "decision": "rejected",
            "policy_evidence": [reason]
        }