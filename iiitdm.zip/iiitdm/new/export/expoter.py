import json
from datetime import datetime


class ResultsExporter:

    def __init__(
        self,
        ranking_results,
        interview_questions,
        schedule_log,
        pipeline_history,
        leave_decision,
        escalation_results
    ):
        self.data = {
            "generated_at": datetime.utcnow().isoformat() + "Z",
            "ranking_results": ranking_results,
            "interview_questions": interview_questions,
            "schedule_log": schedule_log,
            "pipeline_history": pipeline_history,
            "leave_decision": leave_decision,
            "escalation": escalation_results
        }
    def export_results(self, file_path="final_results.json"):
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=4, ensure_ascii=False)

        print(f"\nResults exported successfully to {file_path}")
        return self.data