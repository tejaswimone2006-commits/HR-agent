# scheduling/scheduler.py

from datetime import datetime, timedelta
import uuid


class InterviewScheduler:

    def __init__(self):
        self.booked_slots = []  # audit log of all scheduled interviews

    def schedule(
        self,
        candidate_id,
        interviewer_id,
        candidate_slots,
        interviewer_slots,
        duration_minutes=30
    ):
        """
        candidate_slots & interviewer_slots:
        list of tuples → [(start_datetime, end_datetime), ...]
        """

        for c_start, c_end in candidate_slots:
            for i_start, i_end in interviewer_slots:

                # Find overlap window
                overlap_start = max(c_start, i_start)
                overlap_end = min(c_end, i_end)

                if overlap_start < overlap_end:
                    # Enough time?
                    if (overlap_end - overlap_start) >= timedelta(minutes=duration_minutes):

                        proposed_end = overlap_start + timedelta(minutes=duration_minutes)

                        if not self._has_conflict(interviewer_id, overlap_start, proposed_end):
                            booking = {
                                "schedule_id": str(uuid.uuid4()),
                                "candidate_id": candidate_id,
                                "interviewer_id": interviewer_id,
                                "start_time": overlap_start.isoformat(),
                                "end_time": proposed_end.isoformat(),
                                "created_at": datetime.utcnow().isoformat() + "Z"
                            }

                            self.booked_slots.append(booking)
                            return True, booking

        return False, "No valid slot available."

    def _has_conflict(self, interviewer_id, start, end):
        for booking in self.booked_slots:
            if booking["interviewer_id"] == interviewer_id:
                existing_start = datetime.fromisoformat(booking["start_time"])
                existing_end = datetime.fromisoformat(booking["end_time"])

                # Overlap detection
                if start < existing_end and end > existing_start:
                    return True
        return False

    def get_schedule_log(self):
        return self.booked_slots