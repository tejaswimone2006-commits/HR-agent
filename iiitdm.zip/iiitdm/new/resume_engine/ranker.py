import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from resume_engine.skill_parser import extract_skills

def rank_candidates(resume_path, jd_path):
    resumes = pd.read_csv(resume_path)
    jd = pd.read_csv(jd_path)

    jd_text = jd.iloc[0]["jd_text"]

    # TF-IDF similarity
    corpus = resumes["resume_text"].tolist() + [jd_text]
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(corpus)

    similarity_scores = cosine_similarity(
        tfidf_matrix[:-1], tfidf_matrix[-1]
    ).flatten()

    ranked = []

    for idx, row in resumes.iterrows():
        skills = extract_skills(row["resume_text"])
        skill_match_score = len(skills)

        final_score = (0.7 * similarity_scores[idx]) + (0.3 * skill_match_score)

        ranked.append({
            "candidate_id": row["candidate_id"],
            "skills": skills,
            "score": round(final_score, 3)
        })

    ranked.sort(key=lambda x: x["score"], reverse=True)
    return ranked