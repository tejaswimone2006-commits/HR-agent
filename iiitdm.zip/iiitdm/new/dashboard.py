import streamlit as st
import json
import pandas as pd
from pathlib import Path

st.set_page_config(page_title="HR AI Agent Dashboard", layout="wide")

st.title("HR Autonomous Agent")

# Load JSON
file_path = Path("final_results.json")

if not file_path.exists():
    st.error("final_results.json not found. Run main.py first.")
    st.stop()

with open(file_path, "r", encoding="utf-8") as f:
    data = json.load(f)

# ------------------------------
# Ranking Results
# ------------------------------
st.header("📊 Candidate Ranking")

ranking_df = pd.DataFrame(data["ranking_results"])
st.dataframe(ranking_df, use_container_width=True)

# ------------------------------
# Interview Questions
# ------------------------------
st.header("🧠 Interview Questions")

questions = data["interview_questions"]

st.subheader(f"Candidate: {questions['candidate_id']}")
st.write(f"Difficulty Level: **{questions['difficulty_level']}**")

st.markdown("### Technical Questions")
for q in questions["technical"]:
    st.write("- ", q)

st.markdown("### Behavioral Questions")
for q in questions["behavioral"]:
    st.write("- ", q)

# ------------------------------
# Scheduling
# ------------------------------
st.header("📅 Interview Schedule")

schedule_df = pd.DataFrame(data["schedule_log"])
st.dataframe(schedule_df, use_container_width=True)

# ------------------------------
# Pipeline History
# ------------------------------
st.header("🔁 Pipeline State History")

pipeline_df = pd.DataFrame(data["pipeline_history"])
st.dataframe(pipeline_df, use_container_width=True)

# ------------------------------
# Leave Decision
# ------------------------------
st.header(" Leave Decision")

leave = data["leave_decision"]

st.write(f"Decision: **{leave['decision'].upper()}**")
if leave["decision"] == "approved":
    st.write(f"Leave Type: {leave['leave_type']}")
    st.write(f"Days: {leave['days']}")

st.markdown("### Policy Evidence")
for reason in leave["policy_evidence"]:
    st.write("- ", reason)

# ------------------------------
# Escalation
# ------------------------------

for key, value in data["escalation"].items():
    st.write(f"**{key.capitalize()}**")
    st.write("Escalate:", value["escalate"])
    st.write("Reason:", value["reason"])
    st.write("---")