import streamlit as st
import json
import pandas as pd
from pathlib import Path

st.set_page_config(page_title="HR AI Agent Dashboard", layout="wide")

st.title("🚀 HR Autonomous Agent Dashboard")

# Load JSON
file_path = Path("final_results.json")

if not file_path.exists():
    st.error("final_results.json not found. Run main1.py first.")
    st.stop()

with open(file_path, "r", encoding="utf-8") as f:
    data = json.load(f)

# ------------------------------
# Candidate Ranking
# ------------------------------
st.header("📊 Candidate Ranking")

ranking_df = pd.DataFrame(data.get("ranking_results", []))
st.dataframe(ranking_df, use_container_width=True)

# ------------------------------
# Interview Questions
# ------------------------------
st.header("🧠 Interview Questions")

questions = data.get("interview_questions")

if questions:
    st.subheader(f"Candidate: {questions.get('candidate_id', 'N/A')}")
    st.write(f"Difficulty Level: **{questions.get('difficulty_level', 'N/A')}**")

    st.markdown("### Technical Questions")
    for q in questions.get("technical", []):
        st.write("- ", q)

    st.markdown("### Behavioral Questions")
    for q in questions.get("behavioral", []):
        st.write("- ", q)
else:
    st.info("No interview questions available.")

# ------------------------------
# Interview Schedule
# ------------------------------
st.header("📅 Interview Schedule")

schedule_df = pd.DataFrame(data.get("schedule_log", []))
st.dataframe(schedule_df, use_container_width=True)

# ------------------------------
# Pipeline History
# ------------------------------
st.header("🔁 Pipeline State History")

pipeline_df = pd.DataFrame(data.get("pipeline_history", []))
st.dataframe(pipeline_df, use_container_width=True)

# ------------------------------
# Leave Decision
# ------------------------------
st.header("🏖 Leave Decision")

leave = data.get("leave_decision")

if leave:
    st.write(f"Decision: **{leave.get('decision', '').upper()}**")

    if leave.get("decision") == "approved":
        st.write(f"Leave Type: {leave.get('leave_type')}")
        st.write(f"Days: {leave.get('days')}")

    st.markdown("### Policy Evidence")
    for reason in leave.get("policy_evidence", []):
        st.write("- ", reason)
else:
    st.info("No leave decision data available.")

# ------------------------------
# Escalation Status
# ------------------------------
st.header("🚨 Escalation Status")

escalation_data = data.get("escalation", {})

for key, value in escalation_data.items():
    st.write(f"**{key.capitalize()}**")
    st.write("Escalate:", value.get("escalate"))
    st.write("Reason:", value.get("reason"))
    st.write("---")