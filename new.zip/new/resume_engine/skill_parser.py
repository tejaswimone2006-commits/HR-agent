SKILL_SET = {
    "python", "java", "ml", "machine learning",
    "sql", "excel", "power bi", "rest", "api",
    "spring", "microservices", "pandas", "numpy"
}

def extract_skills(text: str):
    text = text.lower()
    extracted = set()

    for skill in SKILL_SET:
        if skill in text:
            extracted.add(skill)

    return list(extracted)